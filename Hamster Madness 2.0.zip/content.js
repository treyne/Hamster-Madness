console.log('Hamster Madness 2.0: Скрипт загружен');

function replaceIframeSrc() {
  document.querySelectorAll('iframe').forEach((ifr, index) => {
    console.log(`Iframe #${index}: src = ${ifr.src}`);  // Логируем все iframe src

    if (ifr.src.includes('tgWebAppPlatform=weba') || ifr.src.includes('tgWebAppPlatform=web')) {
      console.log(`Iframe #${index}: заменен src`);
      ifr.src = ifr.src.replace(/tgWebAppPlatform=web[a]?/, 'tgWebAppPlatform=android');
    } else {
      console.log(`Iframe #${index}: не содержит tgWebAppPlatform=weba или tgWebAppPlatform=web`);
    }
  });
}

// Изначальная проверка
replaceIframeSrc();

// Используем MutationObserver для отслеживания появления новых iframe
const observer = new MutationObserver(() => {
  replaceIframeSrc();
});

observer.observe(document.body, { childList: true, subtree: true });
